import numpy as np
import random
import math

def pathfinder2(sourceDATA, destSTORAGE,G,k,DATA_set, STORAGE_set):
    #print(sourceDATA, destSTORAGE)
    Reward_Table= np.matrix(np.zeros(shape=(k,k)))
    for x in G[destSTORAGE]:
        Reward_Table[x,destSTORAGE] = 100
        Reward_Table[destSTORAGE,x] = 100

    Q_Table = np.matrix(np.zeros(shape=(k,k)))
    Q_Table -= 100
    for node in G.nodes:
        for x in G[node]:
            Q_Table[node,x] = 0
            Q_Table[x,node] = 0

    def nextnumber(start, EXPLORATION_rate):
        random_value = random.uniform(0, 1)
        if random_value < EXPLORATION_rate:
                sample = G[start]
        else:
                sample = np.where(Q_Table[start,] == np.max(Q_Table[start,]))[1]
        next_node = int(np.random.choice(sample, 1))
        return next_node

    """
    **************************************************************************************************************************************
    
        THE MAIN CHANGE TO HELP WITH COOPERATIVE LEARNING 
        OUR MAIN GOAL IS TO GET THE DATA NODES OFFLOADED TO A STORAGE NODE SO STILL A: [SOURCE -> DESTINATION] PROBLEM
        However, we do need to address the quality of the nodes, so here we have 3 levels of evaluating each step of the agent's walk
        
        LVL 1: the node encounters an empty storage nodes and gets an extra bonus 
               the storage node is then set to full for the next encounter
               
        LVL 2: the node encounters a storage node, but it was already taken by a previous journey.
               the storage node is then set back to empty for the next part of the journey (to open up other cases of assignmen)
               
        LVL 3: the node encounters a non storage node
               the agent gets a slight punishment indicating how 'far' into the journey they're at. The further the data node is from the
               storage node, the less 'valuable' that decision is compared to a closer available data node becomes 
               
    **************************************************************************************************************************************
    """
    def updateQ_Table(n1, n2, LEARNING_rate, discount):
        max_index = np.where(Q_Table[n2,] == np.max(Q_Table[n2,]))[1]
        if max_index.shape[0] > 1:
            max_index = int(np.random.choice(max_index, size=1))
        else:
            max_index = int(max_index)
        max_value = Q_Table[n2, max_index]

        # is the selected node a Storage node
        if np.isin(n2, STORAGE_set[:,0]) :
            location = ((np.where(STORAGE_set[:, 0] == n2))[0][0])
            if (STORAGE_set[location,1] == 0):
                #reward for finding a free storage node to offload the DATA
                Additional_bonus = 1.5
                STORAGE_set[location, 1] == 1 # to set that they landed on a free node and taking that space
            else:
                # a SLIGHT punishment but not as harsh
                Additional_bonus = .95
                STORAGE_set[location, 1] == 0
        else: # it was not a storage node, so it gets no bonus and slight punishment for the longer journey at all
            Additional_bonus = .65
        Q_Table[n1, n2]  = int(Additional_bonus*(1 - LEARNING_rate) * Q_Table[n1, n2] + LEARNING_rate * (Reward_Table[n1, n2] + discount * max_value))
        #print(Q_Table[n1,n2])


    walk = 10 * (pow(6,int(math.log(k))*2) )  # as k increases, the walks needs to increase as well.. especially k = 32

    def learn(EXPLORATION_rate, LEARNING_rate, DISCOUNT):
           for i in range(int(walk)):
               # Start is going to be from any node from the DATA_NODE_SET
               start = np.random.choice(k)
               nextnode = nextnumber(start, EXPLORATION_rate)
               #print(nextnode)
               updateQ_Table(start, nextnode, LEARNING_rate, DISCOUNT)

    def ListPath(DATAnode,STORAGEnode):
        full_path = [DATAnode]
        NEXTnode = np.argmax(Q_Table[DATAnode,])
        full_path.append(NEXTnode)
        while NEXTnode != STORAGEnode:
            NEXTnode = np.argmax(Q_Table[NEXTnode,])
            full_path.append(NEXTnode)
        return full_path

    learn(0.5, 0.85, 0.7)

    final_path = ListPath(sourceDATA, destSTORAGE)
    hops = len(final_path) - 1
    print('From data node: [', sourceDATA, '] to [', destSTORAGE, '] storage node takes', hops , 'hops!')

    return final_path, Q_Table