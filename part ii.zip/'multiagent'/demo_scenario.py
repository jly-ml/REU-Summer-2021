import networkx as nx
import matplotlib.pyplot as plt
from pathfinder2 import *

# create the 5 node scenario (to address the situation for when a storage node is full and cannot take in any data
edges = [(0,1),(1,2),(2,3)]
G = nx.Graph()
G.add_edges_from(edges)
pos = nx.spring_layout(G)
nx.draw_networkx_nodes(G,pos)
nx.draw_networkx_edges(G,pos)
nx.draw_networkx_labels(G,pos)
#plt.show()


STORAGE_CAP = 1   # how much units can a storage node store

# information that will get broadcasted
DATA_NODE_STATUS = np.array([ [1, 1], [3, 1]])
STORAGE_NODE_STATUS = np.array([ [0, 0], [2, 0],[4,1],[5,1]])

K = 4 # total nodes in the graph
walk = 50000

DATA_NODE_LIST= (DATA_NODE_STATUS[:,0])
STORAGE_NODE_LIST = STORAGE_NODE_STATUS[:,0]
# check condition that there is enough storage nodes to offload all data nodes

# takes out the storage nodes that are already full and can't take the extra data offloaded from another node
X = np.sort(np.nonzero(STORAGE_NODE_STATUS[:,1])[0])[::-1]
for x in X:
    STORAGE_NODE_LIST = np.delete(STORAGE_NODE_LIST, x)

# CONDITION CHECK TO MAKE SURE NETWORK HAS ENOUGH STORAGE NODES TO HAVE ALL DATA NODES OFFLOADED
if len(DATA_NODE_STATUS) > len(STORAGE_NODE_LIST):
    print("ADJUSTMENT REQUIRED: the amount of data nodes given is larger than the amount of available storage nodes")

else:
    learning_rate = .8

    Q_table = np.matrix(np.zeros(shape=(K,K)))
    Q_table -= 100

    CUMULATIVE_Q_Table = np.matrix(np.zeros(shape =(K,K)))
    print("*********************************************** PRIMER ***********************************************")

    episodes = int(input("Enter in how many episodes you want to run for the agent >> "))

    print('******************************************************** TRAINING  ********************************************************')
    for each_episode in range(0,episodes):
        fp, Q_holder = (pathfinder2(np.random.choice(DATA_NODE_LIST),np.random.choice(STORAGE_NODE_LIST),G,K,DATA_NODE_LIST, STORAGE_NODE_STATUS))
        CUMULATIVE_Q_Table = CUMULATIVE_Q_Table + Q_holder

    # we are adding all the agent's  Q tables to simulate cooperative learning repeated over 1000 episodes
    print('****************************************************** TRAINING DONE ******************************************************')

    print("CUMULATIVE Q TABLE \n",CUMULATIVE_Q_Table)

    print('********************************************************* RESULTS *********************************************************')

    print("After training for ", episodes ,"episodes, our agent(s) learned the following ")
    for each_data_node in DATA_NODE_LIST:
        MAX_VALUE = np.max(CUMULATIVE_Q_Table[each_data_node][0].flatten())
        #print('ROW ',np.ravel(CUMULATIVE_Q_Table[each_data_node:,]))
        #print(((np.where(np.ravel(CUMULATIVE_Q_Table[each_data_node:,])== MAX_VALUE ))[0][0]))
        print("OFFLOAD DATA FROM NODE:" , each_data_node, 'TO NODE:', np.where(np.ravel(CUMULATIVE_Q_Table[each_data_node:,])== MAX_VALUE )[0][0], "with MAX Value being:", MAX_VALUE)
