from sensor_network import *
from pathfinder2 import *

STORAGE_CAP = 1   # how much units can a storage node store

"""   
# TEST CASE 1: 4 nodes total
edges = [(0,1),(1,2),(2,3)]
G = nx.Graph()
G.add_edges_from(edges)
pos = nx.spring_layout(G)
nx.draw_networkx_nodes(G,pos)
nx.draw_networkx_edges(G,pos)
nx.draw_networkx_labels(G,pos)
plt.show()
"""

""" 
TEST CASE 2: 9 nodes total 
DATA_NODE_STATUS = np.array([ [1, 1], [3, 1]])
#STORAGE_NODE_STATUS = np.array([ [0, 0], [2, 0],[4,1],[5,1]])
edges = [(0,1),(1,3),(6,3),(6,5),(5,4),(0,4),(4,7),(5,8),(7,8),(6,2),(8,2)]
G = nx.Graph()
G.add_edges_from(edges)
pos = nx.spring_layout(G)
nx.draw_networkx_nodes(G,pos)
nx.draw_networkx_edges(G,pos)
nx.draw_networkx_labels(G,pos)

# information that will get broadcasted
DATA_NODE_STATUS = np.array([ [1, 1], [6, 1]])
STORAGE_NODE_STATUS = np.array([ [4, 0], [7, 0]])
"""

K = int(input('Enter in your K-value to build your KxK sensor network:  '))
G = build_sensor_network(K)

CONFIRMATION_data , CONFIRMATION_storage = 'N' ,  'N'
DATA_NODE_STATUS = list()
STORAGE_NODE_STATUS = list()

K = K*K  #to get the accurate amount of nodes on the network graph

while(CONFIRMATION_data == 'N'):
    data_list = list()
    DATA_NODE_ID = int(input("Enter node ID that is a DATA NODE >>   " ))
    DATA_NODE_AMT = int(input("\nEnter in how many packets needs to be offloaded - default is 1 >>   "))
    data_list.append(DATA_NODE_ID)
    data_list.append(DATA_NODE_AMT)
    DATA_NODE_STATUS.append(data_list)
    print(data_list)
    CONFIRMATION_data = str(input('\nWas this the last listing of Data nodes? Y/N    ')).upper()

while(CONFIRMATION_storage == 'N'):
    storage_list = list()
    STORAGE_NODE_ID = int(input("\nEnter node ID that is a STORAGE NODE >>   " ))
    STORAGE_NODE_AMT = int(input("\nEnter in how many units is currently stored in the given storage node - default is 0 >>   "))
    storage_list.append(STORAGE_NODE_ID)
    storage_list.append(STORAGE_NODE_AMT)
    print(storage_list)
    STORAGE_NODE_STATUS.append(storage_list)

    CONFIRMATION_storage  = str(input('\nWas this the last listing of Storage nodes? Y/N    ')).upper()

DATA_NODE_STATUS = np.array(DATA_NODE_STATUS)
STORAGE_NODE_STATUS = np.array(STORAGE_NODE_STATUS)
DATA_NODE_LIST= (DATA_NODE_STATUS[:,0])
STORAGE_NODE_LIST = STORAGE_NODE_STATUS[:,0]

# check condition that there is enough storage nodes to offload all data nodes
print(DATA_NODE_LIST)
print(STORAGE_NODE_LIST)
# takes out the storage nodes that are already full and can't take the extra data offloaded from another node
X = np.sort(np.nonzero(STORAGE_NODE_STATUS[:,1])[0])[::-1]
for x in X:
    STORAGE_NODE_LIST = np.delete(STORAGE_NODE_LIST, x)

# CONDITION CHECK TO MAKE SURE NETWORK HAS ENOUGH STORAGE NODES TO HAVE ALL DATA NODES OFFLOADED
if len(DATA_NODE_STATUS) > len(STORAGE_NODE_LIST):
    print("ADJUSTMENT REQUIRED: the amount of data nodes given is larger than the amount of available storage nodes")

else:

    Q_table = np.matrix(np.zeros(shape=(K,K)))
    Q_table -= 100

    CUMULATIVE_Q_Table = np.matrix(np.zeros(shape =(K,K)))
    print("*********************************************** PRIMER ***********************************************")

    episodes = int(input("Enter in how many episodes you want to run for the agent >> "))

    print('******************************************************** TRAINING  ********************************************************')
    for each_episode in range(0,episodes):
        fp, Q_holder = (pathfinder2(np.random.choice(DATA_NODE_LIST),np.random.choice(STORAGE_NODE_LIST),G,K,DATA_NODE_LIST, STORAGE_NODE_STATUS))
        CUMULATIVE_Q_Table = CUMULATIVE_Q_Table + Q_holder

    # we are adding all the agent's  Q tables to simulate cooperative learning repeated over 1000 episodes
    print('****************************************************** TRAINING DONE ******************************************************')

    print("CUMULATIVE Q TABLE \n",CUMULATIVE_Q_Table)

    print('********************************************************* RESULTS *********************************************************')

    print("After training for ", episodes ,"episodes, our agent(s) learned the following ")
    for each_data_node in DATA_NODE_LIST:
        MAX_VALUE = np.max(CUMULATIVE_Q_Table[each_data_node][0].flatten())

        #print('ROW ', each_data_node ,np.ravel(CUMULATIVE_Q_Table[each_data_node:,]))
        #print(((np.where(np.ravel(CUMULATIVE_Q_Table[each_data_node:,])== MAX_VALUE ))[0][0]))
        print("OFFLOAD DATA FROM NODE:" , each_data_node, 'TO NODE:', np.where(np.ravel(CUMULATIVE_Q_Table[each_data_node:,])== MAX_VALUE )[0][0], "with MAX Value being:", MAX_VALUE)
